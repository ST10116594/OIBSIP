/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numberguessinggame;

import java.util.Random;
//import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class NumberGuessingGame {

    /**
     * @param args the command line arguments
     */
    
     // Function that implements the
    // number guessing game
   
  public static void main(String[] args) {
        // TODO code application logic here
         //Scanner Class
         
        Random random = new Random();

        int minNumber = 1;
        int maxNumber = 100;
        //int targetNumber = random.nextInt(maxNumber - minNumber + 1) + minNumber;
        //int attempts = 0;
        //initial score
        //int score = 100;
        //initial point
        int points = 1000;
        //number of rounds
        int totalRounds = 3;
        int totalScore =0;

        JOptionPane.showMessageDialog(null, "Welcome to the Number Guessing Game!");
        
        
        for(int round = 1; round <= totalRounds; round++){
            int targetNumber = random.nextInt(maxNumber - minNumber + 1) + minNumber;
            int attempts = 0;
            int score = 1000; // Initial score for each round
            
            JOptionPane.showMessageDialog(null, "Round " + round + " I have selected a number between " + minNumber + " and " + maxNumber + ".");

        while (attempts < 5) { //5 Attempts
            String input = JOptionPane.showInputDialog(null, "Enter your guess:");
            int guess = Integer.parseInt(input);
            attempts++;

            if (guess == targetNumber) {
                JOptionPane.showMessageDialog(null, "Congratulations! You've guessed the correct number in " + attempts + " attempts! Your score for this round is: " + score + "Your point is: " + points);
                //add score to total score
                totalScore += score;
                break; //next round
            } else if (guess < targetNumber) {
                JOptionPane.showMessageDialog(null, "Too low! Try again.");
            } else {
                JOptionPane.showMessageDialog(null, "Too high! Try again.");
            }
        }
        
        // Deduct points for each attempt
            score -= 20;
            
        // Calculate points based on attempts
         if (attempts <= 5) {
             // Deduct 200 points for first 5 attempts
                points -= 200; 
            } else {
             // Deduct 100 points for subsequent attempts
                points -= 100; 
            }
         
          // Update score based on attempts
                if (attempts <= 5) {
                    score -= 200; // Deduct 200 points for first 5 attempts
                } else {
                    score -= 100; // Deduct 100 points for subsequent attempts
                }
                
          // Display score for each round
            JOptionPane.showMessageDialog(null, "Round " + round + " Score: " + score);
             
        JOptionPane.showMessageDialog(null, "Sorry, you've used up your attempts. The correct number was " + targetNumber + "." + "\nYour total score is: " + score + "\nThe number of points you aquired is: " + points);
        
        
        //JOptionPane.showMessageDialog(null, "Your total score is: " + score);
        
       // JOptionPane.showMessageDialog(null, "The number of points you aquired is " + points);
  }
  JOptionPane.showMessageDialog(null, "Game Over! Your total score for all rounds is: " + totalScore);
}
}  
  

         
        
    
     