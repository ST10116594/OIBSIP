/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmain2;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author user
 */
public class UserDatabase {
    // userId, User object
    private final Map<String, User> users; 

    public UserDatabase() {
        users = new HashMap<>();
        // Initialize with sample users
        users.put("user1", new User("user1", "1234", 1000));
        users.put("user2", new User("user2", "5678", 500));
        users.put("user3", new User("user3", "9101112", 10000));
    }

    public boolean isValidUser(String userId, String pin) {
        return users.containsKey(userId) && users.get(userId).getPin().equals(pin);
    }

    public User getUser(String userId) {
        return users.get(userId);
    }
    
}
