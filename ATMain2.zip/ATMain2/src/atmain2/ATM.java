/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmain2;

import java.util.Scanner;

/**
 *
 * @author user
 */
class ATM {
    
        UserDatabase userDB = new UserDatabase();
        TransectionHistory transactionHistory = new TransectionHistory();
        Scanner atm = new Scanner(System.in);

    void start() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Welcome to the ATM");
        System.out.print("Enter user ID: ");
        String userId = atm.nextLine();
        System.out.print("Enter PIN: ");
        String pin = atm.nextLine();

        if (userDB.isValidUser(userId, pin)) {
            System.out.println("Login successful.");
            User user = userDB.getUser(userId);
            performTransactions(user);
        } else {
            System.out.println("Invalid credentials. Please try again.");
        }
    }

    private void performTransactions(User user) {
        boolean quit = false;
        while (!quit) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Withdraw");
            System.out.println("2. Deposit");
            System.out.println("3. Transfer");
            System.out.println("4. View Transaction History");
            System.out.println("5. Quit");
            System.out.print("Enter your choice: ");
            int choice = atm.nextInt();
            atm.nextLine(); 
            // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = atm.nextDouble();
                    atm.nextLine(); 
                    // Consume newline
                    if (user.getBalance() >= withdrawAmount) {
                        Transaction.withdraw(user, withdrawAmount);
                        System.out.println("Withdrawal successful. Current balance: " + user.getBalance());
                        transactionHistory.addTransaction("Withdrawal of $" + withdrawAmount);
                    } else {
                        System.out.println("Insufficient funds.");
                    }
                    break;
                case 2:
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = atm.nextDouble();
                    atm.nextLine();
                    // Consume newline
                    Transaction.deposit(user, depositAmount);
                    System.out.println("Deposit successful. Current balance: " + user.getBalance());
                    transactionHistory.addTransaction("Deposit of $" + depositAmount);
                    break;
                case 3:
                    System.out.print("Enter recipient user ID: ");
                    String recipientId = atm.nextLine();
                    System.out.print("Enter amount to transfer: ");
                    double transferAmount = atm.nextDouble();
                    atm.nextLine(); 
                    // Consume newline
                    User recipient = userDB.getUser(recipientId);
                    if (recipient != null) {
                        if (user.getBalance() >= transferAmount) {
                            Transaction.transfer(user, recipient, transferAmount);
                            System.out.println("Transfer successful. Current balance: " + user.getBalance());
                            transactionHistory.addTransaction("Transfer of $" + transferAmount + " to " + recipientId);
                        } else {
                            System.out.println("Insufficient funds.");
                        }
                    } else {
                        System.out.println("Recipient not found.");
                    }
                    break;
                case 4:
                    System.out.println("Transaction History:");
                    transactionHistory.getTransactionHistory().forEach((transaction) -> {
                        System.out.println(transaction);
            });
                    break;
                case 5:
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    quit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
}
