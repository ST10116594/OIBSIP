/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atmain2;

/**
 *
 * @author user
 */
public class Transaction {
    
    public static void withdraw(User user, double amount) {
        //withdrawal logic
        double balance = user.getBalance();
        balance -= amount;
        user.setBalance(balance);
    }

    public static void deposit(User user, double amount) {
        //Deposit logic 
        double balance = user.getBalance();
        balance += amount;
        user.setBalance(balance);
    }

    public static void transfer(User sender, User recipient, double amount) {
        //Tranfer logic 
        double senderBalance = sender.getBalance();
        double recipientBalance = recipient.getBalance();
        sender.setBalance(senderBalance - amount);
        recipient.setBalance(recipientBalance + amount);
    }
    
}
